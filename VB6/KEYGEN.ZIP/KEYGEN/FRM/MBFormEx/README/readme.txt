MB Extended Form Control
version 1.2
Copyright 2000 by Marco Bellinaso


NOTE:
FormEx ActiveX requires the runtime DLL for Visual Basic 6 (msvbvm60.dll).
If you are using an older VB version, you can download the runtime on Microsoft web site at
http://support.microsoft.com/download/support/mslfiles/Vbrun60.exe
See the About Box for more information.


CONTACT INFORMATIONS:
You can contact the author at mbellinaso@vb2themax.com
Download the latest version of the control on www.vb2themax.com


CONTROL HISTORY
  - Version 1.0 - December 1999

  - Version 1.1 - March 2000
	- BUG FIX: the control crashes when you select a display resolution with 32 bit.
	- BUG FIX: the control isn't compatible with the PopMenu ActiveX by VB Accelerator.

  - Version 1.2 - August 2000
	- BUG FIX: the control can't be used in a MDIchild form.

If you find new bugs contact me, please.