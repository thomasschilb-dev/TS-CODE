This code uses the fmod.dll API.
It can be downloaded as freeware at www.fmod.org

MOD, IT, XM, and S3M files can be downloaded at www.modplug.com
