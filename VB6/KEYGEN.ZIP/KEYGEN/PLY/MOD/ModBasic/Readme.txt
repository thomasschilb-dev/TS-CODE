Idea/Copyright (c) Denis Wiegand
Big Thanks go out to:
B. Olaf R. for helping on coding

And Thanks to Brett Paterson for his 
great dokument about mod players.

This modplayer is still under developed!!!

Autor of "ground zero": fleshbrain / crs
Autor of "Axelf"      : ?
Autor of "At bus mix" : Type1
Autor of "ChannelTest": by me
Autor of "3D Demo tune"     : mad freak/anarchy 1991

History#
##########Homework :) (not yet released versions)################
v (TEST): I began with loading the samples and played them,
	  and heard only a "crackksss" and a litle bit of 
	  main sample. I noticed that the sample are (signed eight bit)
	  so i got a nice function by Olaf who fixed that problem. 
	  No i code a first player with many errors and wrongs,
	  but it has played thats is the main thing of a Modplayer :)

v 0.0.1b:
	 I have written a much clean Player function,
	 mods like "Axelf" with no effects are played
	 not correct yet.

###############After i released my first Player##################
v 0.1.0b:
	Jeaa, Axelf is now plaing with no errors, only the speed.
	(Set the speed manually before i release the 0.2.0b version, 
	sorry i have not found out how this work)
	Mods are Playing with no effects and no Channel stopping
	there is a start i thought. Now, i inserted a good background
	and ModInfos.

v 0.1.1b:
	I had the idea to make an Debug menu, generaly for me, to see mistakes
	while playing an mod. 

v 0.1.2b:
	I code an channel fix, to stop not used samples.

v 0.1.3b:
	I got and new, volume bas from Olaf and inseted them, 
	and removed them because i dont know how to reset the 
	volume on samples with no volume effects. (i exert me :) )

v 0.1.4b:	
	I noticed, that a channel is not played and needed
	some time to find that error, it was fixed after
	i do "for i = 1 to 4" > "for i = 1 To Channels" 
	and all channels are played. A new IDE for the player is there
	to :) Now i recode the entire player function until to the
	version 0.2.0b. Hope that all samples+loops and volume are
	correct played and ChannelTest.mod to!. 
        until then i wish you much fun with the 
	first VB ModPlayer :) c.u in next version :)

#################################################################################
Denis

Note:
	If have add a not correct working mod, you cann compare
	that in the new version it sounds and on a old version
	it sounds :) (3D demo tune(mf))
