<?php

header("Location: ./");

?>