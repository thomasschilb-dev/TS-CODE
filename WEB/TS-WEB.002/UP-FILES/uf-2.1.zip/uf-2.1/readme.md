===============================================================================
 UP-FILES/UF
===============================================================================

UF IS A USER INTERFACE FOR UPLOADING FILES VIA THE BROWSER.


UP-FILES 2.1
-------------------------------------------------------------------------------

+ COMPLETELY REDESIGNED USER INTERFACE


UP-FILES 2.0
-------------------------------------------------------------------------------

+ EN/DE-CRYPT FILENAME'S IN SHA-256 WITH NCRYPT CLASS IN c/class.ncrypt.php
+ UF_KEY WITH SHA-256 


UP-FILES 1.1
-------------------------------------------------------------------------------

+ NEW DIRECTORIES, FOR SECURE
+ COUNTER WITH IP'S, LOGGED IN /i/*.IP


UP-FILES 1.0
-------------------------------------------------------------------------------

+ INITALIZE UP-FILES SCRIPT


-------------------------------------------------------------------------------

*** DON'T FORGET TO SET WRITE PERMISSIONS
DIRECTORY c,d,i
FILES footer.php, index.php, no.dat, no.php, upload.php
TO CHMOD 777 ***


===============================================================================
