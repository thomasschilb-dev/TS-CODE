<?php

/*

MIT License

Copyright (c) 2023 Thomas Schilb

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

thomas_schilb@outlook.com
www.thomasschilb.com

*/

$target_dir = "d/"; // data, file uploads
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
/* $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION)); */
/*
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }
}
*/
// Check if file already exists
if (file_exists($target_file)) {
  include('header.html');
  echo "<center>SORRY! FILE ALREADY EXISTS.<br><a href='./'>GO BACK</a></center>";
  include('footer.php');
  $uploadOk = 0;
}
/*
// Check file size (100MB)
if ($_FILES["fileToUpload"]["size"] > 9000000000) {
  include"header.html";
  echo "<center>SORRY!<br><br>YOUR FILE IS LARGER THAN 10MB.</center><br>";
  include('footer.php');
  $uploadOk = 0;
}
*/
/*
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}
*/
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
	$fileName = htmlspecialchars( basename( $_FILES["fileToUpload"]["name"]));
	$Size = htmlspecialchars( basename( $_FILES["fileToUpload"]["size"]));
	$fileSize = round($Size / 1024 / 1024,2) . ' MB';
	$Name = preg_replace('/\.[^.]+$/','',$fileName);
    include('header.html');
    echo "<center>CONGRATULATIONS!<br><br><a href='./d/".$fileName."'>".$Name."</a><br>(".$fileSize.")<br><br>HAS BEEN UPLOADED SUCCESSFULLY.</center>";
	include('footer.php');
  } else {
	include('header.html');
    echo "<center>SOMETHING WENT WRONG!<br><br>THERE WAS AN ERROR UPLOADING YOUR FILE.</center>";
	include('footer.php');
  }
}
?>