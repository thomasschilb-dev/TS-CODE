<!DOCTYPE html>

<!--

MIT License

Copyright (c) 2023 Thomas Schilb

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

thomas_schilb@outlook.com
www.thomasschilb.com

-->

<head>
<style type="text/css">
a {
	color: #C0C0C0;
}
a:visited {
	color: #C0C0C0;
}
a:active {
	color: #C0C0C0;
}
a:hover {
	color: #31C8F9;
}
.auto-style1 {
	font-size: 10px;
}
</style>
<title>FILE-UPLOAD</title>
</head>

<body style="color: #C0C0C0; background-color: #232323">
<br><br><hr><br><center>
&copy; 2023 <a href="./">UP-FILES</a><br><span class="auto-style1">Powered 
by </span><a href="https://github.com/mukto90/ncrypt" target="_blank">
<span class="auto-style1">NCRYPT</span></a><br class="auto-style1"><br>
<?PHP include("no.php"); ?>
</center>
</font>