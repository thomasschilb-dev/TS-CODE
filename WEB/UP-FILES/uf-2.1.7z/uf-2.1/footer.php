<!DOCTYPE html>

<!--

MIT License

Copyright (c) 2023 Thomas Schilb

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

thomas_schilb@outlook.com
www.thomasschilb.com

-->

<head>
<style type="text/css">
a {
	color: #C0C0C0;
}
a:visited {
	color: #C0C0C0;
}
a:active {
	color: #C0C0C0;
}
a:hover {
	color: #31C8F9;
}
.uf_footer-style1 {
	font-size: 23px;
}
.uf_footer-style2 {
	background-color: #000000;
}
.uf_footer-style3 {
	text-align: right;
	background-color: #232323;
}
.uf_footer-style4 {
	font-size: 18px;
}
</style>
<title>FILE-UPLOAD</title>
</head>

<body style="margin: 0; color: #C0C0C0; background-color: #000000">
<table cellpadding="10" cellspacing="1" class="uf_footer-style2" style="width: 100%">
	<tr>
		<td class="uf_footer-style3"><span class="uf_footer-style4"><br>Powered 
by </span><a href="https://github.com/thomasschilb-dev/ncrypt" target="_blank">
<span class="uf_footer-style4">NCRYPT</span></a><span class="uf_footer-style4">/<a href="src/" target="_blank">UF-2.1</span></a></td>
	</tr>
</table>
<center>
<br class="uf_footer-style1"><span class="uf_footer-style1">&copy; 2023 </span> <a href="./">
<span class="uf_footer-style1">UP-FILES.COM</span></a><br class="uf_footer-style1"><br class="uf_footer-style1">
<br class="uf_footer-style1">
<?PHP include("no.php"); ?>
</center>