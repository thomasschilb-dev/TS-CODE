<?php
include 'src/class.ncrypt.php'; // un-comment this if needed

$ncrypt = new since8\Ncrypt;

$ncrypt->set_secret_key( '^&-my-key-&^' );	// optional, but STRONGLY recommended
$ncrypt->set_secret_iv( '#@)-my-iv-#*$' );	// optional, but STRONGLY recommended
$ncrypt->set_cipher( 'AES-256-CBC' );		// optional

// encrypt a plain text/string
$encrypted = $ncrypt->encrypt( 'firedemo.bas' ); // output: QmNEQWMrVHpHdFErL0VHTXdmUGJoZz09
echo "ENCRYPT: ".$encrypted."<br>";

// decrypt an encrypted string to it's original plain text/string
$decrypted = $ncrypt->decrypt( 'QmNEQWMrVHpHdFErL0VHTXdmUGJoZz09' ); // output: firedemo.bas
echo "DECRYPT: ".$decrypted."<br>";